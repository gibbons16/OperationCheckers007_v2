/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CheckersClient007;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 *
 * @author Brian
 */
public class Board extends JPanel {

    private final int NUM_SQUARES = 8;
    private Square[][] squares = new Square[NUM_SQUARES][NUM_SQUARES];
    ImageIcon player1;
    String BLACK_IMAGE = "src\\Images\\black.jpg";
    String RED_IMAGE = "src\\Images\\red.jpg";
    private int width;
    private int height;
    public static Color color1 = new Color(184, 134, 11);
    public static Color color2 = new Color(139, 69, 19);

    public Board() {
        width = 800;
        height = 800;
        this.setSize(width, height);
        GridLayout layout = new GridLayout(NUM_SQUARES, NUM_SQUARES);
        
        this.setLayout(layout);
        createBoard();
    }

    public Board(int height, int width) {

        this.height = height;
        this.width = width;
        this.setSize(width, height);
        GridLayout layout = new GridLayout(NUM_SQUARES, NUM_SQUARES);
        this.setLayout(layout);
        createBoard();

    }

    private void createBoard() {
        Color squareColor;
        for (int row = 0; row < NUM_SQUARES; row++) {
            for (int col = 0; col < NUM_SQUARES; col++) {
                if ((row + col) % 2 == 0) {

                    squareColor = color1;
                } else {
                    squareColor = color2;
                }
                Square square = new Square(width / NUM_SQUARES, height / NUM_SQUARES,
                        row, col, squareColor, this);
                squares[row][col] = square;
                this.add(square);
            }
        }
        intiliazeTest();
        
    }

    public Square[][] getAllSquares()
    {
    	return squares;
    }
    public void clearAllPieces()
    {
    	for(int i = 0; i < this.NUM_SQUARES; i++)
    	{
    		for(int j = 0; j < this.NUM_SQUARES; j++)
    		{
    			squares[i][j].setPiece(null);
    		}
    	}
    }
    private void intiliazeTest()
    {
    	System.out.println("Testing.......");
    	    
    	    	for(int i = 0; i < this.NUM_SQUARES; i++)
    	    	{
    	    		for(int j = 0; j < this.NUM_SQUARES; j++)
    	    		{
    	    			if ((i + j) % 2 == 0 && i < 3) 
    	    				this.setPiece(i,j,PieceType.BLACK);
    	    			else if ((i + j) % 2 == 0 && i > 4) 
    	    				this.setPiece(i,j,PieceType.RED);
    	    		}
    	    	}
    	    
    }
    
    public void setPiece(int row, int col, PieceType type)
    {
    	if(row < this.NUM_SQUARES && col < this.NUM_SQUARES)
    	{
    		if(type == PieceType.BLACK)
    			squares[row][col].setPiece(new Piece( this.BLACK_IMAGE,  type,  row,  col));
    		else
    			squares[row][col].setPiece(new Piece( this.RED_IMAGE,  type,  row,  col));
    	}
    	
    
    }
 }
  

