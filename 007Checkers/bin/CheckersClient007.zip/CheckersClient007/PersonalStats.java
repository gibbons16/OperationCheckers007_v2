package CheckersClient007;

import javax.swing.JPanel;
import java.awt.GridLayout;
import javax.swing.JLabel;

public class PersonalStats extends JPanel {

	/**
	 * Create the panel.
	 */
	public PersonalStats() {
		setLayout(new GridLayout(10, 2, 0, 0));
		
		JLabel lblPersonalStats = new JLabel("Personal Stats");
		add(lblPersonalStats);
		
		JLabel label = new JLabel("\"\"");
		add(label);
		
		JLabel lblTotalGames = new JLabel("Total Games: ");
		add(lblTotalGames);
		
		JLabel lblFfff = new JLabel("0");
		lblFfff.setLabelFor(lblFfff);
		add(lblFfff);
		
		JLabel lblGamesWon = new JLabel("Games Won");
		add(lblGamesWon);
		
		JLabel label_1 = new JLabel("0");
		add(label_1);
		
		JLabel lblGamesLost = new JLabel("Games Lost: ");
		add(lblGamesLost);
		
		JLabel label_2 = new JLabel("0");
		add(label_2);
		
		JLabel lblPiecesJumped = new JLabel("Pieces Jumped: ");
		add(lblPiecesJumped);
		
		JLabel label_3 = new JLabel("0");
		add(label_3);
		
		JLabel lblPiecesLost = new JLabel("Pieces Lost: ");
		add(lblPiecesLost);
		
		JLabel label_4 = new JLabel("0");
		add(label_4);
		
		JLabel lblKingsCreated = new JLabel("Kings created: ");
		add(lblKingsCreated);
		
		JLabel label_5 = new JLabel("0");
		add(label_5);
		
		JLabel lblKingsSlain = new JLabel("Kings slain: ");
		add(lblKingsSlain);
		
		JLabel label_6 = new JLabel("0");
		add(label_6);
		
		JLabel lblAvgSurvingPieces = new JLabel("Avg surving pieces (on Win)");
		add(lblAvgSurvingPieces);
		
		JLabel label_7 = new JLabel("0");
		add(label_7);
		
		JLabel lblMostSurvingPieces = new JLabel("Most surving Pieces (on Win): ");
		add(lblMostSurvingPieces);
		
		JLabel label_8 = new JLabel("0");
		add(label_8);

	}

}
